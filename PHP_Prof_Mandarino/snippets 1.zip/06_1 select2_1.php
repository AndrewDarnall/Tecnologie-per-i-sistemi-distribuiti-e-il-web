<?php  
if ($result->num_rows > 0)
{
?>
    <label for="guests">Scegli un id:</label>
    <select name="table_id" id="table_id">
<?php     
    while($row = $result->fetch_assoc())
    {
        print "<option value='" . $row['id']. "'>" . $row['firstname']. "</option>\n";
    }
}
?>
    </select> 
<?php 