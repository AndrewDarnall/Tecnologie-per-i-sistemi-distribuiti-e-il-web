<?php
require_once('functions/html.php');
require_once('functions/conf.php');

PrintTop();

require_once('../Private/connection.php');

//select
$sql = "SELECT id, firstname, lastname FROM MyGuests ORDER BY id";
$result = $conn->query($sql);

if ($result->num_rows > 0)
{
  while($row = $result->fetch_assoc()) 
  {
    echo "        id: " . $row["id"]. " - Nome: " . $row["firstname"]. " - Cognome: " . $row["lastname"]. "<br>\n";
  }
}

$conn->close();

PrintBottom();

?>
