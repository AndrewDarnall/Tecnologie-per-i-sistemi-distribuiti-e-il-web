<?php
header("Location: http://localhost/");
exit;//assicurarsi di non produrre alcun output quando si fa il redirect
?>
