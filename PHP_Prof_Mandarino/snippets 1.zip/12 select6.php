<?php
require_once('functions/html.php');

PrintTop("select");
require_once('functions/conf.php');
require_once('../Private/connection.php');

//select
$sql = "SELECT email FROM MyGuests ORDER BY id";
$result = $conn->query($sql);

if ($result->num_rows > 0)
{
?>
    <table>
<?php while($row = $result->fetch_assoc())
      {
?>
        <tr>
            <td><?php print $row["email"]; ?></td>
            <td><a href="where6.php?email=<?php print $row["email"]; ?>">view</a></td>
        </tr>
<?php        
       }
?>
    </table>
<?php   
}

$conn->close();
PrintBottom();

?>