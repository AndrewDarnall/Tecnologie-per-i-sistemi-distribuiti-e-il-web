<?php
require_once 'functions/connessione.php';
require_once 'functions/html.php';

PrintTopTitle('select esempio');

//$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';
//$lang = $_GET['lang'];
$lang = $_GET['lang'] ?? 'en';

if($lang=='it')
{
    print "ciao";
}
else
{
    print "hello";
}

$conn->close();
PrintBottom();
