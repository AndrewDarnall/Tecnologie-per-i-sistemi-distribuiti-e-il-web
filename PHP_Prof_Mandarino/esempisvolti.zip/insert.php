<?php
require_once('functions/connessione.php');

$sql = "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('John', 'Doe', 'john@example.com')";
if (defined('DebugQuery'))
    print "La query e':$sql<br>";

if ($conn->query($sql) === true)
{
    echo "New record created successfully. L'ID e': " . $conn->insert_id;
}
else
{
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
