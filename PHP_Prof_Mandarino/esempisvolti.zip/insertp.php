<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}

// prepare and bind
$stmt = $conn->prepare("INSERT INTO MyGuests (firstname, lastname, email) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $firstname, $lastname, $email);

for($i=0;$i<100;$i++)
{
    $firstname = "John$i";
    $lastname = "Doe$i";
    $email = "john$i@example.com";
    $stmt->execute();
}



echo "New records created successfully";

$stmt->close();
$conn->close();
