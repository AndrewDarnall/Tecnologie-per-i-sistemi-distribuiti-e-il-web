<?php
require_once('conf.php');
require_once('../Private/dati.php');

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error)
{
    if (defined('DebugConnectionError'))
        die("Connection failed: " . $conn->connect_error);
    else
        die();
}
if (defined('DebugConnection'))
    echo "Connected successfully";
