<?php
    //define('DebugConnection', 1);
    define('DebugConnectionError', 1);
    //define('DebugPOST', 1);
    define('DebugQuery', 1);
    //define('Debug', 1);
    //error_reporting(0);

    //if (defined('DebugConnection'))
?>