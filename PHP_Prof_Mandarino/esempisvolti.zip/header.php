<?php
//header("HTTP/1.1 404 Not Found");
//header("HTTP/1.1 500 Internal Server Error");
header("Location: http://www.unict.it");
