#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int *V;
pthread_t thA, thB, thC;

void *produttore_A(void *dummy)
{
	int i;
	for (i = 1; i < 10000; i += 2)
		V[i] = 2*i;

	return NULL;
}

void *produttore_B(void *dummy)
{
	int j;
	for (j = 0; j < 10000; j += 2)
		V[j] = 2*j+1;

	return NULL;
}

void *consumatore_C(void *dummy)
{
	pthread_join(thA, NULL);
	pthread_join(thB, NULL);

	int i, subsum = 0;
	for (i = 0; i < 10000; i++)
	{
		subsum += V[i];
		if (i % 500 == 499)
		{
			printf("%d-%d: %d\n", i-499, i, subsum);
		}
	}

	return NULL;
}

int main(int argc, char **argv)
{
	V = calloc(10000, sizeof(int));
	pthread_create(&thA, NULL, produttore_A, NULL);
	pthread_create(&thB, NULL, produttore_B, NULL);
	pthread_create(&thC, NULL, consumatore_C, NULL);

	pthread_exit(NULL);
}
