#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>

int a, b;
pthread_t thP, thC;

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
int turno = 0; // 0 = P, 1 = C

void *produttore_P(void *dummy)
{
	bool esci = false;
	
	while (!esci)
	{
		pthread_mutex_lock(&mutex);
		if (turno != 0)
			pthread_cond_wait(&cond, &mutex);

		printf("produco\n");

		if (a == -10 && b == -10)
			esci = true;
		else
		{
			a = (rand()%10) + 1;
			b = (rand()%10) + 1;
		}

		turno = 1;
		pthread_cond_signal(&cond);
		pthread_mutex_unlock(&mutex);
	}

	return NULL;
}

void *consumatore_C(void *dummy)
{
	bool esci = false;
	while (!esci)
	{
		pthread_mutex_lock(&mutex);
		if (turno != 1)
			pthread_cond_wait(&cond, &mutex);

		printf("a=%d b=%d\n", a, b);
		if (a+b < 10)
		{
			esci = true;
			a = -10;
			b = -10;
		}

		turno = 0;
		pthread_cond_signal(&cond);
		pthread_mutex_unlock(&mutex);
	}

	return NULL;
}

int main(int argc, char **argv)
{
	srand(time(NULL));

	pthread_create(&thP, NULL, produttore_P, NULL);
	pthread_create(&thC, NULL, consumatore_C, NULL);

	pthread_join(thP, NULL);
	pthread_join(thC, NULL);

	printf("Esco\n");
	pthread_exit(NULL);
	return 0;
}
