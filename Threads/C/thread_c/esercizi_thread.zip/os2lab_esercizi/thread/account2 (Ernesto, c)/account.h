#include <pthread.h>

typedef void *(*pthread_func)(void *);

typedef struct
{
    int val;
    unsigned int op;
    pthread_mutex_t mutex;
    pthread_cond_t cond;
} account_t;

typedef struct
{
    int val;
    int op;
} op_result_t;

int init_acc(account_t *acc);

op_result_t add_acc(account_t *acc, int val);

op_result_t sub_acc(account_t *acc, int val);
