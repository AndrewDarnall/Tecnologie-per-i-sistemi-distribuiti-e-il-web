#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#include "account.h"

#define ADD_DELAY 200000
#define SUB_DELAY 100000

int rep = 20;
account_t acc;

void *add_routine(void *arg)
{
    for (int i = 0; i < rep; i++)
    {
        usleep(rand() % ADD_DELAY);
        op_result_t v = add_acc(&acc, 100);
        printf("%s> op. %u - Saldo: %d\n", (char *)arg, v.op, v.val);
    }
    return NULL;
}

void *sub_routine(void *arg)
{
    for (int i = 0; i < rep * 2; i++)
    {
        usleep(rand() % SUB_DELAY);
        op_result_t v = sub_acc(&acc, 50);
        printf("%s> op. %u - Saldo: %d\n", (char *)arg, v.op, v.val);
    }
    return NULL;
}

int main(int argc, char *argv[])
{
    if (argc == 2)
        rep = atoi(argv[1]) > 0 ? atoi(argv[1]) : rep;

    pthread_t A, B, C, D;
    init_acc(&acc);
    srand(time(NULL));
    pthread_create(&A, NULL, (pthread_func)add_routine, "add_A");
    pthread_create(&B, NULL, (pthread_func)add_routine, "\t\t\t\tadd_B");
    pthread_create(&C, NULL, (pthread_func)sub_routine, "\t\t\t\t\t\t\t\tprel_C");
    pthread_create(&D, NULL, (pthread_func)sub_routine, "\t\t\t\t\t\t\t\t\t\t\t\t\tprel_D");

    pthread_join(A, NULL);
    pthread_join(B, NULL);
    pthread_join(C, NULL);
    pthread_join(D, NULL);
}