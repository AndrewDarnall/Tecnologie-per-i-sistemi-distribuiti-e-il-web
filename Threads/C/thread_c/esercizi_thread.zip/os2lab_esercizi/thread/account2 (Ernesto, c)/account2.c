#include "account.h"

int init_acc(account_t *acc)
{
    acc->val = 0;
    acc->op = 0;
    pthread_mutex_init(&(acc->mutex), NULL);
    pthread_cond_init(&(acc->cond), NULL);
    return 1;
}

op_result_t add_acc(account_t *acc, int val)
{
    if (val < 0)
        sub_acc(acc, -val);
    pthread_mutex_lock(&(acc->mutex));
    op_result_t result;
    acc->val += val;
    result.val = acc->val;
    result.op = ++acc->op;
    pthread_cond_broadcast(&(acc->cond));
    pthread_mutex_unlock(&(acc->mutex));
    return result;
}

op_result_t sub_acc(account_t *acc, int val)
{
    if (val < 0)
        add_acc(acc, -val);
    pthread_mutex_lock(&(acc->mutex));
    while (acc->val < val)
        pthread_cond_wait(&(acc->cond), &(acc->mutex));
    op_result_t result;
    acc->val -= val;
    result.val = acc->val;
    result.op = ++acc->op;
    pthread_mutex_unlock(&(acc->mutex));
    return result;
}