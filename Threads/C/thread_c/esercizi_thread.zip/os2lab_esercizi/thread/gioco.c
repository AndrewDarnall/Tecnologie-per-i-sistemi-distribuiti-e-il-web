#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <time.h>

int posizione=0;
int vittorie_tp0=0, vittorie_tp1=0;

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

void lock()
{
	pthread_mutex_lock(&mutex);
}

void unlock()
{
	pthread_mutex_unlock(&mutex);
}

void signal()
{
	pthread_cond_signal(&cond);
}

void signalAll()
{
	pthread_cond_broadcast(&cond);
}

void wait()
{
	pthread_cond_wait(&cond, &mutex);
}

int generaRecupero(){
	srand(time(NULL));
	return rand() % 4;
}

int generaForza(){
	srand(time(NULL));
	return rand() % 6;
}

void* player0(void* arg)
{
	int forza;
	int recupero;
	int running=0;
	while(running==0)
	{		
		forza=generaForza();
		recupero=generaRecupero();
		usleep(recupero*1000);
		
		lock();
			if(posizione >= 10){
				vittorie_tp1++;
				posizione=0;
				signal();
				printf("THREAD 1 svegliato!\n");
			}else{
				posizione-=forza;
				if(posizione<-10){
					unlock();
					wait();
					printf("THREAD 0 addormentato!\n");
				}
			}
			unlock();
			
			
			lock();
			printf("THREAD 0 %d\n", vittorie_tp0);
			if(vittorie_tp0 >=10 || vittorie_tp1 >=10)
				running=1;
			unlock();
			
	}
}

void* player1(void* arg)
{
	int forza;
	int recupero;
	int running=0;
	while(running==0)
	{		
		forza=generaForza();
		recupero=generaRecupero();
		usleep(recupero*1000);
		
		lock();
			if(posizione <= -10){
				vittorie_tp0++;
				posizione=0;
				signal();
				printf("THREAD 0 svegliato!\n");
			}else{
				posizione+=forza;
				if(posizione>10){
					unlock();
					wait();
					printf("THREAD 1 addormentato!\n");
				}
			}
			unlock();
			
			lock();
			printf("THREAD 1 %d\n", vittorie_tp1);
			if(vittorie_tp0 >=10 || vittorie_tp1 >=10)
				running=1;
			unlock();
	}
}

int main(int argc, char** argv)
{

	pthread_t tp[2];
	
	pthread_create(&tp[0], NULL, player0, NULL);	
	pthread_create(&tp[1], NULL, player1, NULL);	
	
	pthread_join(tp[0], NULL);
	pthread_join(tp[1], NULL);
	
	if(vittorie_tp0>vittorie_tp1)
		printf("THREAD 0 VINCE \n");
	else if(vittorie_tp1>vittorie_tp0)
		printf("THREAD 1 VINCE \n");
	
	
			
	return 0;
}
