#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

int m;

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t m1_5 = PTHREAD_COND_INITIALIZER;
pthread_cond_t m6_10 = PTHREAD_COND_INITIALIZER;

void *fun_p1(void *dummy)
{
	while (1) {
		pthread_mutex_lock(&mutex);
		if (m <= 5) {
			pthread_cond_signal(&m1_5);
			m = rand() % 10 + 1;
			printf("P1 imposta m = %d\n", m);
		} else 
			pthread_cond_wait(&m6_10, &mutex);
		pthread_mutex_unlock(&mutex);
	}
}

void *fun_p2(void *dummy)
{
	while (1) {
		pthread_mutex_lock(&mutex);
		if (m >= 6) {
			pthread_cond_signal(&m6_10);
			m = rand() % 10 + 1;
			printf("\t\t\t\tP2 imposta m = %d\n", m);
		} else 
			pthread_cond_wait(&m1_5, &mutex);
		pthread_mutex_unlock(&mutex);
	}
}

int main(int argc, char **argv)
{
	pthread_t th1, th2;

	srand(time(NULL));
	m = rand() % 10 + 1;

	printf("m inizializzato a %d\n", m);

	pthread_create(&th1, NULL, &fun_p1, NULL);
	pthread_create(&th2, NULL, &fun_p2, NULL);

	pthread_detach(th1);
	pthread_detach(th2);

	pthread_exit(NULL);
	return 0;
}
