/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dmi.tsdw;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author franc
 */
public class WSCinemaServlet extends HttpServlet {
    static String nomeFilm;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        if(request.getParameter("operation") == null){
            try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet WSCinemaServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet WSCinemaServlet at " + request.getContextPath() + "</h1>");
            out.println("<h1>errore nel  form</h1>");
            out.println("<a href=\"./\"> Torna alla Home</a>");
            out.println("</body>");
            out.println("</html>");
            }
        }else if(request.getParameter("operation").equals("addFilm")){
            
            if(request.getParameter("filmName").equals("") || request.getParameter("filmRegista").equals("") ||
                        request.getParameter("numeroSala").equals("") || request.getParameter("numeroPosti").equals("")){
                try (PrintWriter out = response.getWriter()) {
                    out.println("errore, ritenta <br><a href=\"./\">Home</a>");
                }
                return;
            }
            String nome = request.getParameter("filmName");
            String regista = request.getParameter("filmRegista");
            int sala = Integer.parseInt(request.getParameter("numeroSala"));
            int numeroPosti = Integer.parseInt(request.getParameter("numeroPosti"));
            
            
            
            addFilm(nome, regista, numeroPosti, sala);
            try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet WSCinemaServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet WSCinemaServlet at " + request.getContextPath() + "</h1>");
            out.println("<h1>"+ showFilmByName(nome) +"</h1>");
            out.println("<a href=\"./\"> Torna alla Home</a>");
            out.println("</body>");
            out.println("</html>");
            }
        }else if(request.getParameter("operation").equals("showAllFilms")){
            try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet WSCinemaServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet WSCinemaServlet at " + request.getContextPath() + "</h1>");
            out.println("<h1>"+ showAllFilms() +"</h1>");
            out.println("<a href=\"./\"> Torna alla Home</a>");
            out.println("</body>");
            out.println("</html>");
            }
        }else if(request.getParameter("operation").equals("searchFilm")){
            
            if(request.getParameter("searchFilmName").equals("") || request.getParameter("searchFilmName") == null ){
                try (PrintWriter out = response.getWriter()) {
                    out.println("errore, ritenta <br><a href=\"./\">Home</a>");
                }
                return;
            }
            String nome = request.getParameter("searchFilmName");
            try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String film = showFilmByName(nome);
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet WSCinemaServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet WSCinemaServlet at " + request.getContextPath() + "</h1>");
            if(!film.equals("Film non trovato!")){
                out.println("<h1>"+ film+"</h1>");
                out.println("<h2>"+ "Che azione vuoi eseguire sul Film \""+ nome +"\"? </h2>");
                out.println("<form method=\"post\" action=\"#\">");
                     out.println("<input type=\"radio\" name=\"operation\" value=\"deleteFilm\"> Elimina il film<br>");
                     out.println("<input type=\"radio\" name=\"operation\" value=\"changeDescription\"> Cambia la descrizione del film: ");
                     out.println("<textarea name=\"descrizione\"></textarea><br>");
                     out.println("<input type=\"radio\" name=\"operation\" value=\'prenotaFilm\'> Prenota un posto in Sala per "+
                            nome + "<br>");
                     out.println("<input type=\"submit\" value=\"Invio\">");
                out.println("</form>");
                nomeFilm = nome;
            }else{
                out.println("<h1> Film non Trovato! </h1>");
            }
            out.println("<a href=\"./\"> Torna alla Home</a>");
            out.println("</body>");
            out.println("</html>");
            }
        }else if(request.getParameter("operation").equals("changeDescription")){
            String descr = request.getParameter("descrizione");
            if(descr == null){
                try (PrintWriter out = response.getWriter()) {
                    out.println("errore, ritenta <br><a href=\"./\">Home</a>");
                }
                return;
            }
            try (PrintWriter out = response.getWriter()) {
                
            setDescription(nomeFilm, descr);
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet WSCinemaServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet WSCinemaServlet at " + request.getContextPath() + "</h1>");
            out.println("<h2>Cambiata la descrizione del film: "+ nomeFilm + "</h2>");
            out.println("<a href=\"./\"> Torna alla Home</a>");
            out.println("</body>");
            out.println("</html>");
            }
        }else if(request.getParameter("operation").equals("deleteFilm")){
            try (PrintWriter out = response.getWriter()) {
                
            deleteFilmByName(nomeFilm);
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet WSCinemaServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet WSCinemaServlet at " + request.getContextPath() + "</h1>");
            out.println("<h2>Dilm Eliminato!</h2>");
            out.println("<a href=\"./\"> Torna alla Home</a>");
            out.println("</body>");
            out.println("</html>");
            }
        }else if(request.getParameter("operation").equals("prenotaFilm")){
            try (PrintWriter out = response.getWriter()) {
                
            prenotaFilm(nomeFilm);
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet WSCinemaServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet WSCinemaServlet at " + request.getContextPath() + "</h1>");
            out.println("<h2>Biglietto prenotato per \""+ nomeFilm +"\"</h2>");
            out.println("<a href=\"./\"> Torna alla Home</a>");
            out.println("</body>");
            out.println("</html>");
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private static void addFilm(java.lang.String nomeFilm, java.lang.String nomeRegista, int numeriPostiSala, int numeroSala) {
        dmi.tsdw.WSCinemaService_Service service = new dmi.tsdw.WSCinemaService_Service();
        dmi.tsdw.WSCinemaService port = service.getWSCinemaServicePort();
        port.addFilm(nomeFilm, nomeRegista, numeriPostiSala, numeroSala);
    }

    private static boolean deleteFilmByName(java.lang.String nomeFilm) {
        dmi.tsdw.WSCinemaService_Service service = new dmi.tsdw.WSCinemaService_Service();
        dmi.tsdw.WSCinemaService port = service.getWSCinemaServicePort();
        return port.deleteFilmByName(nomeFilm);
    }

    private static int searchFilmByName(java.lang.String nomeFilm) {
        dmi.tsdw.WSCinemaService_Service service = new dmi.tsdw.WSCinemaService_Service();
        dmi.tsdw.WSCinemaService port = service.getWSCinemaServicePort();
        return port.searchFilmByName(nomeFilm);
    }

    private static boolean setDescription(java.lang.String nomeFilm, java.lang.String descrizione) {
        dmi.tsdw.WSCinemaService_Service service = new dmi.tsdw.WSCinemaService_Service();
        dmi.tsdw.WSCinemaService port = service.getWSCinemaServicePort();
        return port.setDescription(nomeFilm, descrizione);
    }

    private static String showAllFilms() {
        dmi.tsdw.WSCinemaService_Service service = new dmi.tsdw.WSCinemaService_Service();
        dmi.tsdw.WSCinemaService port = service.getWSCinemaServicePort();
        return port.showAllFilms();
    }

    private static String showFilmByName(java.lang.String nomeFilm) {
        dmi.tsdw.WSCinemaService_Service service = new dmi.tsdw.WSCinemaService_Service();
        dmi.tsdw.WSCinemaService port = service.getWSCinemaServicePort();
        return port.showFilmByName(nomeFilm);
    }

    private static boolean prenotaFilm(java.lang.String nomeFilm) {
        dmi.tsdw.WSCinemaService_Service service = new dmi.tsdw.WSCinemaService_Service();
        dmi.tsdw.WSCinemaService port = service.getWSCinemaServicePort();
        return port.prenotaFilm(nomeFilm);
    }

}
