/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dmi.tsdw;

import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author franc
 */
@WebService(serviceName = "WSCinemaService")
public class WSCinemaService {
    private List<Film> films = new ArrayList<Film>();
    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "searchFilmByName")
    public int searchFilmByName(@WebParam(name = "nomeFilm") final String nomeFilm) {
        Film f;
        for(int i = 0; i < films.size(); i++){
            f = films.get(i);
            if(f.getNomeFilm().equals(nomeFilm)){
                return i;
            }
        }
        return -1;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "deleteFilmByName")
    public boolean deleteFilmByName(@WebParam(name = "nomeFilm") final String nomeFilm) {
        int index = searchFilmByName(nomeFilm);
        if(index == -1){
           return false; 
        }else {
           films.remove(index);
           return true;
        }
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "addFilm")
    public void addFilm(@WebParam(name = "nomeFilm") final String nomeFilm, @WebParam(name = "nomeRegista") final String nomeRegista, @WebParam(name = "numeriPostiSala") final int numeriPostiSala, @WebParam(name = "numeroSala") final int numeroSala) {
        Film f = new Film(nomeFilm, nomeRegista, numeriPostiSala,numeroSala, "");
        
        films.add(f);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "showFilmByName")
    public String showFilmByName(@WebParam(name = "nomeFilm") final String nomeFilm) {
        int index = searchFilmByName(nomeFilm);
        if(index == -1){
           return "Film non trovato!"; 
        }else {
           return films.get(index).toString();
        }
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "showAllFilms")
    public String showAllFilms() {
        StringBuilder str = new StringBuilder("");
        
        for(Film f : films){
            str.append(f.toString());
            str.append("<br>");
        }
        
        return str.toString();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "setDescription")
    public boolean setDescription(@WebParam(name = "nomeFilm") final String nomeFilm, @WebParam(name = "descrizione") final String descrizione) {
        int index = searchFilmByName(nomeFilm);
        if(index == -1){
           return false; 
        }else {
           films.get(index).setDescrizioneFilm(descrizione);
           return true;
        }
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "prenotaFilm")
    public boolean prenotaFilm(@WebParam(name = "nomeFilm") final String nomeFilm) {
        int index = searchFilmByName(nomeFilm);
        if(index > -1){
           films.get(index).prenotaPostoInSala();
            return true; 
        }
        return false; 
    }
}
