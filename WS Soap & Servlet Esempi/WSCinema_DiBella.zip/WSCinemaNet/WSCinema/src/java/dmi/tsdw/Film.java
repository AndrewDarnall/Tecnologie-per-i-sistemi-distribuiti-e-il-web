/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dmi.tsdw;

/**
 *
 * @author franc
 */
public class Film {
    private String nomeFilm;
    private String nomeRegista;
    private int numeroPostiSala;
    private int numeroSala;
    private String descrizioneFilm;

    public Film(String nomeFilm, String nomeRegista, int numeroPostiSala, int numeroSala, String descrizioneFilm) {
        this.nomeFilm = nomeFilm;
        this.nomeRegista = nomeRegista;
        this.numeroPostiSala = numeroPostiSala;
        this.numeroSala = numeroSala;
        this.descrizioneFilm = descrizioneFilm;
    }

    @Override
    public String toString() {
        return "Film{" + "nomeFilm=" + nomeFilm + ", nomeRegista=" + nomeRegista + ", numeroPostiSala=" + numeroPostiSala + ", numeroSala=" + numeroSala + ", descrizioneFilm=" + descrizioneFilm + '}';
    }
    
    public Film(){}

    public void setNomeFilm(String nomeFilm) {
        this.nomeFilm = nomeFilm;
    }

    public void setNomeRegista(String nomeRegista) {
        this.nomeRegista = nomeRegista;
    }

    public void setNumeroPostiSala(int numeroPostiSala) {
        this.numeroPostiSala = numeroPostiSala;
    }

    public void setNumeroSala(int numeroSala) {
        this.numeroSala = numeroSala;
    }

    public void setDescrizioneFilm(String descrizioneFilm) {
        this.descrizioneFilm = descrizioneFilm;
    }

    public String getNomeFilm() {
        return nomeFilm;
    }

    public String getNomeRegista() {
        return nomeRegista;
    }

    public int getNumeroPostiSala() {
        return numeroPostiSala;
    }

    public int getNumeroSala() {
        return numeroSala;
    }

    public String getDescrizioneFilm() {
        return descrizioneFilm;
    }
    
    public String prenotaPostoInSala(){
        if(this.numeroPostiSala > 0){
            int postoUtente = this.numeroPostiSala;
            numeroPostiSala--;
            return "Posto in Sala "+this.numeroSala+" per \""+this.nomeFilm+"\" prenotato correttamente, il tuo posto è il n."+postoUtente+".";
        }else{
            return "Posti in Sala "+this.numeroSala+" per \""+this.nomeFilm+"\" esauriti per oggi! Ci dispiace";
        }
    }    
    
}
