/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dmi.tsdw;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import java.util.*;

/**
 *
 * @author longo
 */
@WebService(serviceName = "BancaWebService")
public class BancaWebService {
    public HashMap<Integer, Integer> bankAccount = new HashMap<Integer, Integer>(){{
        put(0,0);
        put(1,0);
        put(2,0);
        put(3,0);
        put(4,0);
        put(5,0);
        put(6,0);
        put(7,0);
        put(8,0);
        put(9,0);
    }};
    
    public int selectedAccount = -1;

    /**
     * Web service operation
     */
    @WebMethod(operationName = "setBankAccount")
    public String setBankAccount(@WebParam(name = "n") final int n) {
        
        if(n>=0 && n<=10) {
            selectedAccount=n;
            return "Numero conto corrente settato a " + n;
        }
        return "Conto corrente non presente";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "deposit")
    public String deposit(@WebParam(name = "value") final int value) {
        if(selectedAccount!=-1) {
            int n=bankAccount.get(selectedAccount)+value;
            bankAccount.put(selectedAccount, n);
            return "Versati " + value + " nel conto corrente " + selectedAccount + ". Il totale ammonta a " + bankAccount.get(selectedAccount);
        }
        else return "Conto corrente non settato. Settare prima il conto corrente";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "withdraw")
    public String withdraw(@WebParam(name = "n") final int value) {
        if(selectedAccount!=-1) {
            int n=bankAccount.get(selectedAccount)-value;
            bankAccount.put(selectedAccount, n);
            return "prelevati " + value + " nel conto corrente " + selectedAccount + ". Il totale ammonta a " + bankAccount.get(selectedAccount);
        }
        else return "Conto corrente non settato. Settare prima il conto corrente";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getAmount")
    public String getAmount() {
        if(selectedAccount!=-1) return "Il saldo del conto corrente " + selectedAccount + " è " + bankAccount.get(selectedAccount);
        return "Conto corrente non settato. Settare prima il conto corrente";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "logout")
    public String logout() {
        if(selectedAccount!=-1) {
            selectedAccount=-1;
            return "Logout avvenuto con successo";
        }
        else {
            return "Conto corrente non settato";
        }
       
    }
}
