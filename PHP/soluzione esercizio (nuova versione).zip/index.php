<html>
<head>
    <title>Videoteca</title>
</head>
<body>
<?php

require_once('json_fake_db.php');

$GLOBALS['NewID'] = uniqid();
    
function PrintFilmList()
{
    $array = ReadAllFilms();
    if($array)
    {
        foreach ($array as $film => $data)
        {
            print '<form action="'. $_SERVER['PHP_SELF'] . '" method="post" id="' . $film . '"></form>';
            print "\n";
        }
    }
    ?>
    <form action="<?php print $_SERVER['PHP_SELF'];?>" method="post" id="<?php print $GLOBALS['NewID']; ?>"></form>
    
    <table border="1">
    <th>Titolo</th>
    <th>Anno</th>
    <th>Paese</th>
    <th>Regista</th>
    <th>Link</th>
    <th></th>
    <th>Azioni</th>
    
    <?php
    if($array)
    {
        foreach ($array as $film => $data)
        {
            $array = $data;
            ?>
            <tr>
                <td>
                    <input type="hidden" id="id" name="id" value="<?php print $film; ?>" form="<?php print $film; ?>">
                     <input type="text" id="titolo" name="titolo" value="<?php print $array['titolo']; ?>" form="<?php print $film; ?>">
                </td>
                <td>
                    <input type="text" id="anno" name="anno" value="<?php print $array['anno']; ?>" form="<?php print $film; ?>">
                </td>
                <td>
                    <input type="text" id="paese" name="paese" value="<?php print $array['paese']; ?>" form="<?php print $film; ?>">
                </td>
                <td>
                    <input type="text" id="regista" name="regista" value="<?php print $array['regista']; ?>" form="<?php print $film; ?>">
                </td>
                <td>
                    <input type="text" id="link" name="link" value="<?php print $array['link']; ?>" form="<?php print $film; ?>">
                </td>
                <td>
                    <?php
                    if($array['link']!="")
                    {
                        print '<input type="submit" name="aprilink" value="apri il link" form="'. $film .'">';
                        print "\n";
                    }
                    ?>
                </td>
                <td>
                    <input type="submit" name="modifica" value="modifica" form="<?php print $film; ?>">
                    <input type="submit" name="elimina" value="elimina" form="<?php print $film; ?>">
                </td>
            </tr>
            <?php
        }
    }
    ?>

    <tr>
    <td>
        <input type="hidden" id="id" name="id" value="<?php print $GLOBALS['NewID']; ?>" form="<?php print $GLOBALS['NewID']; ?>">
        <input type="text" id="titolo" name="titolo" value="" form="<?php print $GLOBALS['NewID']; ?>">
    </td>
    <td><input type="text" id="anno" name="anno" value="" form="<?php print $GLOBALS['NewID']; ?>"></td>
    <td><input type="text" id="paese" name="paese" value="" form="<?php print $GLOBALS['NewID']; ?>"></td>
    <td><input type="text" id="regista" name="regista" value="" form="<?php print $GLOBALS['NewID']; ?>"></td>
    <td><input type="url" id="link" name="link" value="" form="<?php print $GLOBALS['NewID']; ?>"></td>
    <td>
    </td>
    <td><input type="submit" name="nuovo" value="nuovo" form="<?php print $GLOBALS['NewID']; ?>"></td>
    </tr>
    
    </table>
    
    <?php
}

if($_SERVER['REQUEST_METHOD']==='POST')
{
    $action="";
    if(isset($_POST['nuovo']))
        $action="nuovo";
    
    if(isset($_POST['modifica']))
        $action="modifica";
        
    if(isset($_POST['elimina']))
        $action="elimina";
        
    if(isset($_POST['aprilink']))
        $action="link";

    switch ($action)
    {
    case "nuovo":
        $id=$_POST['id'];
        $titolo=$_POST['titolo'];
        $anno=$_POST['anno'];
        $paese=$_POST['paese'];
        $regista=$_POST['regista'];
        $link=$_POST['link'];
            
        if($titolo!="" && $anno!="" && $paese!="" && $regista!="")    
        {
            $data = array('titolo' => $titolo, 'anno' => $anno, 'paese' => $paese, 'regista' => $regista, 'link' => $link);
            CreateFilm($id, $data);
        }
        else
        {
            ?>
            <script type="text/javascript">
                alert('inserire titolo, anno, paese e regista');
            </script>
            <?php
        }
        header("Refresh:0");
        break;
            
    case "modifica":
        $id=$_POST['id'];
        $titolo=$_POST['titolo'];
        $anno=$_POST['anno'];
        $paese=$_POST['paese'];
        $regista=$_POST['regista'];
        $link=$_POST['link'];
        if($titolo!="" && $anno!="" && $paese!="" && $regista!="")    
        {
            $data = array('titolo' => $titolo, 'anno' => $anno, 'paese' => $paese, 'regista' => $regista, 'link' => $link);
            UpdateFilm($id, $data);
        }
        else
        {
            ?>
            <script type="text/javascript">
                alert('inserire titolo, anno, paese e regista');
            </script>
            <?php
        }
        header("Refresh:0");
        break;
            
    case "elimina":
        $id=$_POST['id'];
        DeleteFilm($id);
        header("Refresh:0");
        break;
            
    case "link":
        $link=$_POST['link'];
        ?>
        <script type="text/javascript">
            window.open('<?php print $link; ?>', '_blank');
        </script>
        <?php
        header("Refresh:0");
        break;
    }   
}
else
    PrintFilmList();
?>
</body>
</html>