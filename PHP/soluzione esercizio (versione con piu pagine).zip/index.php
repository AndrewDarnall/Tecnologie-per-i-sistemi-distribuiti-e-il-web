<html>
<head>
    <title>Videoteca</title>
</head>
<body>
<h2><a href="create.php">Create</a></h2><br>
<h2><a href="read.php">Read</a></h2><br>
<h2><a href="update.php">Update</a></h2><br>
<h2><a href="delete.php">Delete</a></h2><br>
</body>
</html>