<html>
<head>
    <title>Read</title>
</head>
<body>
<a href="index.php">indietro</a><br><br>
<?php

require_once('json_fake_db.php');

$array = ReadAllFilms();
if($array)
{
    foreach ($array as $film => $data)
    {
        ?>
        <form action="<?php print $_SERVER['PHP_SELF'];?>" method="post">
            <input type="hidden" id="id" name="id" value="<?php print $film; ?>">
            Titolo:
            <input type="text" id="titolo" name="titolo" value="<?php print $data['titolo']; ?>" readonly><br>
            Anno:
            <input type="text" id="anno" name="anno" value="<?php print $data['anno']; ?>" readonly><br>
            Paese:
            <input type="text" id="paese" name="paese" value="<?php print $data['paese']; ?>" readonly><br>
            Regista:
            <input type="text" id="regista" name="regista" value="<?php print $data['regista']; ?>" readonly><br>
            Link:<a href="<?php print $data['link']; ?>"><?php print $data['link']; ?></a><br><br>
        </form>  
        <?php
    }
}
?>
<br><br><a href="index.php">indietro</a>
</body>
</html>