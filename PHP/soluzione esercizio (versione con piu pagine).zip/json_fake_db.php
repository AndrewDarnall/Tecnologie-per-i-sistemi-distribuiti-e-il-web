<?php
$GLOBALS['FileName'] = "JSONFAKEDB.txt";
$GLOBALS['ArrayFakeDB'] = array();

function LoadFromJson()
{
    if($file = @fopen($GLOBALS['FileName'], "r"))
    {
        $GLOBALS['ArrayFakeDB'] = json_decode(fread($file, filesize($GLOBALS['FileName'])), true);
        
        fclose($file);
        return true;
    }
    else
    {
        return false;
    }
}

function SaveToJson()
{
    if($file = fopen($GLOBALS['FileName'], "w"))
    {
        $s = json_encode($GLOBALS['ArrayFakeDB']);
        if(fwrite($file, $s))
        {
            fclose($file);
            return true;
        }
        else
        {
            //print "<b>error: can't write on $FileName</b><br>";
            fclose($file);
            return false;
        }
    }
    else
    {
        //print "<b>error: can't open $FileName</b><br>";
        return false;
    }
}

function CreateFilm($id, $data)
{
    LoadFromJson();
    $array=$GLOBALS['ArrayFakeDB'];
    $array[$id]=$data;
    $GLOBALS['ArrayFakeDB']=$array;
    SaveToJson();
}

function ReadAllFilms()
{
    LoadFromJson();
    return $GLOBALS['ArrayFakeDB']; 
}

function UpdateFilm($id, $data)
{
    //DeleteFilm($id);
    CreateFilm($id, $data);
}

function DeleteFilm($id)
{
    LoadFromJson();
    $array=$GLOBALS['ArrayFakeDB'];
    unset($array[$id]);
    $GLOBALS['ArrayFakeDB']=$array;
    SaveToJson();
}
?>