<html>
<head>
    <title>Create</title>
</head>
<body>

<a href="index.php">indietro</a><br><br>
<?php

require_once('json_fake_db.php');

if($_SERVER['REQUEST_METHOD']==='POST')
{
    $id=$_POST['id'];
    $titolo=$_POST['titolo'];
    $anno=$_POST['anno'];
    $paese=$_POST['paese'];
    $regista=$_POST['regista'];
    $link=$_POST['link'];

    if($titolo!="" && $anno!="" && $paese!="" && $regista!="")    
    {
        $data = array('titolo' => $titolo, 'anno' => $anno, 'paese' => $paese, 'regista' => $regista, 'link' => $link);
        CreateFilm($id, $data);
        print 'Record creato con successo. Clicca <a href="' . $_SERVER['PHP_SELF'] . '">qui</a> per crearne un altro.';
    }
    else
    {
        ?>
        <script type="text/javascript">
            alert('inserire titolo, anno, paese e regista');
        </script>
        <?php
    }
}
else
{       
    $GLOBALS['NewID'] = uniqid();

    ?>
    <form action="<?php print $_SERVER['PHP_SELF'];?>" method="post">
        <input type="hidden" id="id" name="id" value="<?php print $GLOBALS['NewID']; ?>">
        Titolo:
        <input type="text" id="titolo" name="titolo" value=""><br>
        Anno:
        <input type="text" id="anno" name="anno" value=""><br>
        Paese:
        <input type="text" id="paese" name="paese" value=""><br>
        Regista:
        <input type="text" id="regista" name="regista" value=""><br>
        Link:
        <input type="url" id="link" name="link" value=""><br>
        <input type="submit" name="nuovo" value="nuovo">

    </form>
<?php

}
?>
<br><br><a href="index.php">indietro</a>
</body>
</html>