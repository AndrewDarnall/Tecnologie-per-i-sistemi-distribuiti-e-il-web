<!-- eqtag1.php -->

<!DOCTYPE html>
<html><body>
First PHP tag below:<BR><BR>
<?php $x = 1; ?>
Second PHP tag below:<BR>
<?= $x+1 ?>
</body></html>
