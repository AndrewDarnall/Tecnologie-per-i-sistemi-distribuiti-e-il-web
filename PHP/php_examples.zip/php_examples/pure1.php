<!-- pure1.php -->
<?php echo "<html>\n<body>\nToday is " . date("l") . "\n</body>\n</html>";
