<!-- pure.php -->
<?php
echo "<html>";
echo "<body>";
echo "Today is ";
echo date("l");
echo "</body>";
echo "</html>";