<?php 
$films = array (
  'Regista1019935861' => 'Titolo1019935861',
  'Regista1874612688' => 'Titolo1874612688',
  'Regista1508806193' => 'Titolo1508806193',
);
