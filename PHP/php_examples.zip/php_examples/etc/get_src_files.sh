#!/usr/bin/env bash

ls -d *.html *.php *.src *.zip | egrep -v '(!README.html|index.html|show_code.php)' | sort
