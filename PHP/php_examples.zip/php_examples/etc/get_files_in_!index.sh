#!/usr/bin/env bash

INDEXFILE='!index.csv'

egrep -v -e '(^\#|^\+|^$)' "$INDEXFILE" | egrep -v '^[-.*],' | cut -d',' -f1 > ${TMPDIR}/a.$$
egrep -v -e '(^\#|^\+|^$)' "$INDEXFILE" | egrep -e '^[-.*],' | cut -d',' -f2 > ${TMPDIR}/b.$$
sort ${TMPDIR}/a.$$ ${TMPDIR}/b.$$
rm ${TMPDIR}/a.$$ ${TMPDIR}/b.$$
