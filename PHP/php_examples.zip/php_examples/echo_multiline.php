<?php

echo 'in PHP questo testo &egrave; su un rigo
e questo su un altro, nell\'argomento di echo 
(racchiuso tra apici (\'))
<BR>';

echo "in PHP questo testo &egrave; su un rigo
e questo su un altro, nell'argomento di echo 
(racchiuso tra virgolette (\"))
<BR>";

?>
<p>
Notare anche l'impiego del backslash per &ldquo;quotare&rdquo;
</p>
