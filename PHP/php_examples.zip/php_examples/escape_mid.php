<!-- escape_mid.php -->

<?php $temperatura = ?>

Come va il tempo?<BR>

<?php = 30; ?>
