#!/usr/bin/env bash

INDEXFILE='!index.csv'
DELIM="                                              "
./etc/get_files_in_\!index.sh > ${TMPDIR}/i.$$
./etc/get_src_files.sh > ${TMPDIR}/s.$$
echo
echo "Non-files in '$INDEXFILE' (remove them)       Files not in '$INDEXFILE' (put them in)"
echo "-------------------------------------------------------------------------------------"
comm -3 --output-delimiter="$DELIM" ${TMPDIR}/i.$$ ${TMPDIR}/s.$$
rm ${TMPDIR}/i.$$ ${TMPDIR}/s.$$
