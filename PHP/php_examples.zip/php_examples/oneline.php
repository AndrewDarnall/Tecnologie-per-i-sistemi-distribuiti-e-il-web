<html><body><i>Today is</i> <?php echo date("l"); ?></body></html>
