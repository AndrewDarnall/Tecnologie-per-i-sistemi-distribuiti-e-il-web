#!/usr/bin/env bash

THISDIR=$(basename $(pwd))
HANDOUT_ALIAS=php_examples
cd ..
ln -s $THISDIR $HANDOUT_ALIAS
zip -r $HANDOUT_ALIAS.zip $HANDOUT_ALIAS/ -x \*/etc/\*~ \*/fixlinks.sh \*.zip \*/\!Handout.sh
rm $HANDOUT_ALIAS
cd $THISDIR
mv ../$HANDOUT_ALIAS.zip .
echo "distribuisci ./$HANDOUT_ALIAS.zip"
