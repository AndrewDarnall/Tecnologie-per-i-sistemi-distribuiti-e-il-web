<!-- escape1.php -->
<html><body>
First PHP tag below:<BR><BR>
<?php $x = 1; ?>
Second PHP tag below:<BR>
<?php echo $x+1; ?>
</body></html>
