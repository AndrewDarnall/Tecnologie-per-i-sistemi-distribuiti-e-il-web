<!-- embedded.php -->
<html>

<body>
    Today is
    <?php echo date("l"); ?>
</body>

</html>