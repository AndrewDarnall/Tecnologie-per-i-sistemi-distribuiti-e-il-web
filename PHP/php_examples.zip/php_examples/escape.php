<!-- escape.php -->
<html><body>
First PHP tag below:<BR><BR>
<?php $x = 1; ?>
Second PHP tag below:<BR>
<?php echo 2; ?>
</body></html>
