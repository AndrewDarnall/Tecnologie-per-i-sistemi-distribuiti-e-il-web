<!-- eqtag0.php -->

<!DOCTYPE html>
<html><body>
<?= PHP_INT_MAX ?>

</body></html>
