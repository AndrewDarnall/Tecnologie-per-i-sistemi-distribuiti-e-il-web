<!DOCTYPE html>
<html>
<body>

<h2>Welcome to the example!</h2>
<p>Some text.</p>
<p>Some more text.</p>

Includo footer:
<?php include_once('footer.php');?>

Include once footer (non si vede) :
<?php include_once 'footer.php';?>

<BR><BR>Require once footer (non si vede) :
<?php require_once 'footer.php';?>

</body>
</html>
