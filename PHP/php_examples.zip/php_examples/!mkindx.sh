#! /bin/bash

INDEXFILE='./!index.csv'

if [ "x$1" = "x-h" ] ; then
    echo "Usage: $0 pattern-for-ls"
    echo "   or: $0 -r (input da $INDEXFILE (deve esistere), scrive su stdout)"
    echo "   or: $0 -w (input $INDEXFILE (deve esistere), scrive su ./index.html)"
    if [ -r $INDEXFILE ] ; then
        echo $INDEXFILE esiste
    fi
    exit
fi

if [ -z $1 ] ; then
    $0 -h
    exit
fi

if [ ! "x$1" = "x-r" ] ; then
    if [ ! "x$1" = "x-w" ] ; then
        # genera indice-elenco per il pattern $1

        FILES=$(ls -f $* 2> /dev/null)
        if [ ! "$FILES" ] ; then
            echo "eseguito: $0 $*"
            echo "il pattern $* non trova alcun file"
            exit
        fi

        # usavo ls, ma non pare serva; in ogni caso, usare "ls -f", se no riordina
        #for f in `ls -f $*` ; do
        for f in $* ; do
            echo "<a href=\"$f target="_blank"\"> `basename $f` </a><br>" ;
        done

        # qui termina la versione con argomento pattern
        exit
    fi
fi

if [ ! -r $INDEXFILE ] ; then
    $0 -h
    exit
fi

# se nella directory corrente c'e' $INDEXFILE, usalo
# come template per nuovo index.html
awk -F',' '
function file_link(filename)
{
   url = "<a href=\"" filename "\" target=\"_blank\"><code>" filename "</code></a>";
   n = split(filename, a, ".")
   if (a[n] == "php")
      url = url " &#91;<a href=\"show_code.php?which="filename"\" target=\"_blank\"><i>src</i></a>&#93;";
   return url;
}
function file_no_link(filename)
{
   url = "<code><u>"filename"</u></code>";
   n = split(filename, a, ".")
   if (a[n] == "php")
      url = url " &#91;<a href=\"show_code.php?which="filename"\" target=\"_blank\"><i>src</i></a>&#93;";
   return url;
}
BEGIN {
   printf "<html lang="it">\n<head>\n";
   printf "<style type=\"text/css\">\n"
   printf "li {\n\tmargin-top: 0.7em;\n\tmargin-bottom: 0.7em;\n}\n";
   printf "code {\n\tbackground-color: #E8E8E8;\n\tcolor: blue;\n";
   printf         "\tfont-family: \"Ubuntu Mono\", \"Lucida Console\";\n";
   printf         "\tfont-size: 92%%;\n";
   printf "\n}\n";

   printf "</style>\n";

   printf "<title></title>\n";
   printf "</head>\n\n<body>\n";
   printf "<ol>\n\n"
}
$1=="#" {printf "<!-- "$2" -->\n\n"}
NF>=2 && $1=="+" {printf "</ol>\n\n<h1>"$2"</h1>"$3"\n<ol>\n"}
NF>=2 && $1!="-" && $1!="*" && $1!="." && $1!="+" && $1!="#" {printf "<li>"file_link($1)" ("$2")</li>\n"; after_li = 1;}
NF==3 && $1=="-" {printf (after_li?"":"<br>") file_link($2) " ("$3")\n" ; after_li = 0;}
NF==3 && $1=="." {printf "&emsp13;" file_link($2) " ("$3")\n"}
NF==3 && $1=="*" {printf (after_li?"":"<br>") file_no_link($2) " ("$3")\n" ; after_li = 0;}
END {printf "</ol>\n<br></body>\n</html>"}
' $INDEXFILE \
| sed -e 's/\[\(.*\)\]/<a href="\1"><code>\1<\/code><\/a>/g' | tee $TMPDIR/index.html

echo
if [ "x$1" = "x-r" ] ; then
    echo "per rendere HTML sopra il nuovo indice:"
    echo cp --backup=t ${TMPDIR}index.html etc/
fi

if [ "x$1" = "x-w" ] ; then
    echo "eseguo: cp --backup=t ${TMPDIR}index.html etc/"
    echo "eseguo: cp --backup=t \!index.csv etc/"
    cp --backup=t index.html etc/
    cp --backup=t \!index.csv etc/
    cp --backup=t ${TMPDIR}index.html etc/
    cp etc/index.html .
    echo "creato nuovo indice"
fi
