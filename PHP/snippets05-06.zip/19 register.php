<?php

require_once('functions/html.php');

PrintTop("registrati");
require_once('functions/conf.php');
require_once('../Private/connection.php');

?>

<h1>Registrati</h1><br>

<form action="saveuser.php" method="post">
    <label for="fname">Nome:</label><br>
    <input type="text" id="fname" name="fname" value=""><br><br>
    
    <label for="lname">Cognome:</label><br>
    <input type="text" id="lname" name="lname" value=""><br><br>
    
    <label for="email">email:</label><br>
    <input type="text" id="email" name="email" value=""><br><br>
    
    <label for="pass">Password (8 characters minimum):</label><br>
    <input type="password" id="pass" name="password" minlength="8" required><br><br>
    
    <input type="submit" name="submit" value="Registrati">
</form> 

<?php

PrintBottom();

?>



        

