<?php

require_once('functions/html.php');

PrintTop("create table");
require_once('functions/conf.php');
require_once('../Private/connection.php');

$nome = isset($_POST['fname']) ? $_POST['fname'] : "";
$cognome = isset($_POST['lname']) ? $_POST['lname'] : "";
$email = isset($_POST['email']) ? $_POST['email'] : "";
$password = isset($_POST['password']) ? $_POST['password'] : "";

if(defined('DebugPOST'))
{
    print "nome=$nome<br>";
    print "cognome=$cognome<br>";
    print "email=$email<br>";
    print "password=$password<br>";
}

//sql insert create table

//ALTER TABLE MyGuests DROP COLUMN id;
$sql = "INSERT INTO MyGuests (firstname, lastname, email, secretpassword) VALUES";
$sql .= " ('$nome', '$cognome', '$email', '$password')";

  
print "<br><h1>la query e': <b>$sql</b></h1><br>";
if ($conn->query($sql) === TRUE)
{
    if(defined('DebugConnection'))
        echo "New record created successfully.<br>";
}
else 
{
    if(defined('DebugConnectionError'))
        echo "Error: " . $sql . "<br>" . $conn->error;
}
  


$conn->close();


PrintBottom();

?>



        

