<?php

require_once('functions/html.php');
require_once('functions/functions.php');

$PostRequest = IsPostRequest();

PrintTop($PostRequest ? "registrazione" : "registrati");

require_once('functions/conf.php');
require_once('../Private/connection.php');

if($PostRequest)
{
    $nome = isset($_POST['fname']) ? $_POST['fname'] : "";
    $cognome = isset($_POST['lname']) ? $_POST['lname'] : "";
    $email = isset($_POST['email']) ? $_POST['email'] : "";
    $password0 = isset($_POST['password0']) ? $_POST['password0'] : "";
    $password1 = isset($_POST['password1']) ? $_POST['password1'] : "";

    if(defined('DebugPOST'))
    {
        print "nome=$nome<br>";
        print "cognome=$cognome<br>";
        print "email=$email<br>";
        print "password0=$password0<br>";
        print "password1=$password1<br>";
    }
    
    $errors=array();
    if(isset($_POST['submit']))
    {
        $ok = true;
        if(!IsEmail($email))
        {
            $ok = false;
            array_push($errors, "Inserire un'email valida");
        }
        if(strlen($nome)<2)
        {
            $ok = false;
            array_push($errors, "Inserire un nome valido");
        }
        
        if(strlen($cognome)<3)
        {
            $ok = false;
            array_push($errors, "Inserire un cognome valido");
        }
        
        if(strlen($password0)<8)//si potrebbero fare altri controlli sulla robustezza
        {
            $ok = false;
            array_push($errors, "Inserire una password valida");
        }
        else
        {
            if($password0 !== $password1)
            {
                $ok = false;
                array_push($errors, "Le password non coincidono");
            }   
        }
        
        if($ok)
        {
            $conn = connect();
            $sql = "INSERT INTO MyGuests (firstname, lastname, email, secretpassword) VALUES";
            $sql .= " ('$nome', '$cognome', '$email', '$password0')";

            if ($conn->query($sql) === TRUE)
            {
                ?><h1>Registrazione effettuata con successo!</h1><br><?php
                if(defined('DebugConnection'))
                    echo "New record created successfully.<br>";
            }
            else 
            {
                if(defined('DebugConnectionError'))
                    echo "Error: " . $sql . "<br>" . $conn->error;
            }
            $conn->close();  
        }
        else
        {
            foreach ($errors as $error)
            {
                print "<h1>$error</h1><br>";
            }
            
            ?>
            <form action="<?php print $_SERVER['PHP_SELF']; ?>" method="post">
                <label for="fname">Nome:</label><br>
                <input type="text" id="fname" name="fname" value="<?php print $nome; ?>"><br><br>

                <label for="lname">Cognome:</label><br>
                <input type="text" id="lname" name="lname" value="<?php print $cognome; ?>"><br><br>

                <label for="email">email:</label><br>
                <input type="text" id="email" name="email" value="<?php print $email; ?>"><br><br>

                <label for="pass0">Password (8 characters minimum):</label><br>
                <input type="password" id="pass0" name="password0" minlength="8" required><br><br>
                
                <label for="pass1">Conferma Password:</label><br>
                <input type="password" id="pass1" name="password1" minlength="8" required><br><br>
                

                <input type="submit" name="submit" value="Registrati">
            </form> 
            <?php
        }
    }
    else
    {
        ?><h1>Qualcosa è andato storto, riprova</h1><br><?php
    }
}
else
{
?>
<h1>Registrati</h1><br>
<form action="<?php print $_SERVER['PHP_SELF']; ?>" method="post">
    <label for="fname">Nome:</label><br>
    <input type="text" id="fname" name="fname" value=""><br><br>
    
    <label for="lname">Cognome:</label><br>
    <input type="text" id="lname" name="lname" value=""><br><br>
    
    <label for="email">email:</label><br>
    <input type="text" id="email" name="email" value=""><br><br>
    
    <label for="pass0">Password (8 characters minimum):</label><br>
    <input type="password" id="pass0" name="password0" minlength="8" required><br><br>
                
    <label for="pass1">Conferma Password:</label><br>
    <input type="password" id="pass1" name="password1" minlength="8" required><br><br>
    
    <input type="submit" name="submit" value="Registrati">
</form> 
<?php
}
PrintBottom();
?>



        

