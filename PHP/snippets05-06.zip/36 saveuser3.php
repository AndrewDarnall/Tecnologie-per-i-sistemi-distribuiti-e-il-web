<?php

require_once('functions/html.php');

PrintTop("save user");
require_once('functions/conf.php');
require_once('../Private/connection.php');

$conn = connect();

$nome = isset($_POST['fname']) ? $_POST['fname'] : "";
$cognome = isset($_POST['lname']) ? $_POST['lname'] : "";
$email = isset($_POST['email']) ? $_POST['email'] : "";
$password = isset($_POST['password']) ? $_POST['password'] : "";

if(defined('DebugPOST'))
{
    print "nome=$nome<br>";
    print "cognome=$cognome<br>";
    print "email=$email<br>";
    print "password=$password<br>";
}

//sql insert create table

$sql = "INSERT INTO MyGuests (firstname, lastname, email, secretpassword) VALUES ('$nome', '$cognome', '$email', '$password');";

if(defined('DebugQuery'))
    print "<br><h1>la query è: <b>$sql</b></h1><br>";

if ($conn->multi_query($sql) === TRUE)
{
    if(defined('DebugConnection'))
        echo "New records created successfully<br>";
}
else 
{
    if(defined('DebugConnectionErrors'))
        echo "Error: " . $sql . "<br>" . $conn->error ."<br>";
}
  
$conn->close();
PrintBottom();
?>



        

