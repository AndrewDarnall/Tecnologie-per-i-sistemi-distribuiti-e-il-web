<?php

require_once('functions/html.php');

PrintTop("registrazione");
require_once('functions/conf.php');
require_once('../Private/connection.php');
require_once('functions/functions.php');

$conn = connect();

$nome = isset($_POST['fname']) ? $_POST['fname'] : "";
$cognome = isset($_POST['lname']) ? $_POST['lname'] : "";
$email = isset($_POST['email']) ? $_POST['email'] : "";
$password = isset($_POST['password']) ? $_POST['password'] : "";

if(defined('DebugPOST'))
{
    print "nome=$nome<br>";
    print "cognome=$cognome<br>";
    print "email=$email<br>";
    print "password=$password<br>";
}

if(IsPostRequest())
{
    if(defined(Debug))
        echo "POST<br>";
    if(isset($_POST['submit']))
    {
        if(defined(Debug))
            echo "submit set<br>";
        //sql insert create table
        $sql = "INSERT INTO MyGuests (firstname, lastname, email, secretpassword) VALUES";
        $sql .= " ('$nome', '$cognome', '$email', '$password')";

        if ($conn->query($sql) === TRUE)
        {
            if(defined('DebugConnection'))
                echo "New record created successfully.<br>";
        }
        else 
        {
            if(defined('DebugConnectionError'))
                echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    else
    {
        if(defined(Debug))
            echo "Error: submit not set";
        header('Location: http://localhost/register2.php');
        exit;
    }
}
else
{
    if(defined(Debug))
        echo "Error: not a post method";
    header('Location: http://localhost/register2.php');
    exit;
}


$conn->close();


PrintBottom();

?>



        

