<?php

require_once('functions/html.php');
require_once('functions/functions.php');

$PostRequest = IsPostRequest();

PrintTop($PostRequest ? "Benvenuto" : "Log in");

require_once('functions/conf.php');
require_once('../Private/connection.php');

if($PostRequest)
{
    $email = isset($_POST['email']) ? $_POST['email'] : "";
    $password = isset($_POST['password']) ? $_POST['password'] : "";

    $conn = connect();
    $email = db_escape_conn_obj($conn, $email);
    
    if(defined('DebugPOST'))
    {
        print "email=$email<br>";
        print "password=$password<br>";
    }
    
    $errors=array();
    if(isset($_POST['submit']))
    {
        $ok = true;
        if(!IsEmail($email))
        {
            $ok = false;
            array_push($errors, "Inserire un'email valida");
        }
        
        if($ok)
        {
            $hash = md5($password);
            if(defined('Debug'))
                print "<br>L'hash della password:$password è $hash<br>";
            
            $sql = "SELECT * FROM MyGuests WHERE email='$email' AND secretpassword='$hash'";

            if(defined('Debug'))
                print "<br>La query è $sql<br>";
            
            $result = $conn->query($sql);
            
            if ($result->num_rows >0)
            {
                $row = $result->fetch_assoc();
                
                print "<h1>Benvenuto ". $row['firstname'] . " " . $row['lastname'] ."!</h1><br>";
            }
            else 
            {
                array_push($errors, 'errore durante l\'accesso. <br><a href="">password dimenticata</a><br><a href="">nome utente dimenticato</a><br>');
                $ok = false;
            }
        }
        
        if(!$ok)
        {
            foreach ($errors as $error)
            {
                print "<h1>$error</h1><br>";
            }
            
            ?>
            <form action="<?php print $_SERVER['PHP_SELF']; ?>" method="post">
                <label for="email">nome untente:</label><br>
                <input type="text" id="email" name="email" value="<?php print $email; ?>"><br><br>

                <label for="pass">Password</label><br>
                <input type="password" id="pass" name="password" minlength="8" required><br><br>
                

                <input type="submit" name="submit" value="entra">
            </form> 
            <?php
        }
    }
    else
    {
        ?><h1>Qualcosa è andato storto, riprova</h1><br><?php
    }
    
    $conn->close();  
}
else
{
?>
<h1>Log in</h1><br>
<form action="<?php print $_SERVER['PHP_SELF']; ?>" method="post">
    <label for="email">nome untente:</label><br>
    <input type="text" id="email" name="email" value=""><br><br>

    <label for="pass">Password</label><br>
    <input type="password" id="pass" name="password" minlength="8" required><br><br>


    <input type="submit" name="submit" value="entra">
</form>
<?php
}
PrintBottom();
?>