<?php

require_once('functions/html.php');

PrintTop("conferma registrazione");
require_once('functions/conf.php');
require_once('../Private/connection.php');
require_once('functions/functions.php');

$conn = connect();

$c = "";
$e = "";

$StateDataOK = 0;
$StateDataCodeEmpty = 1;
$StateDataCodeNotValid = 2;
$StateDataCodeNotFound = 3;
$StateDataEmailEmpty = 10;
$StateDataEmailNotValid = 20;
$StateDataEmailNotFound = 30;

$state = $StateDataOK;

if(HasPresence($_GET['c']))
{
    $c = $_GET['c'];
    if(!HasExactLength($c, 10))
        $state = $StateDataCodeNotValid;
}
else
{
    $state = $StateDataCodeEmpty;
}

if(HasPresence($_GET['e']))
{
    $e = $_GET['e'];
    if(!IsEmail($e))
        $state += $StateDataEmailNotValid;
}
else
{
    $state += $StateDataEmailEmpty;
}

if(defined('Debug'))
    print "\$state=$state<br>";

if($state == $StateDataOK)
{
    $sql = "SELECT randomcode, status FROM MyGuests WHERE email='$e'";
    
    if(defined('DebugQuery'))
        print "<br>la query è: $sql<br>";
    
    $result = $conn->query($sql);

    if(defined('Debug'))
        print "num_rows=". $result->num_rows ."<br>";
    
    if ($result->num_rows > 0)
    {
        $row = $result->fetch_assoc();
        if($row['randomcode'] === $c)
        {
            //il codice corrisponde quindi proviene dal link mandato via email
            if($row['status'] === 'p')
            {
                //aggiorno lo stato a verificato
                $sql = "UPDATE MyGuests SET status='v' WHERE email='$e'";

                if(defined('DebugQuery'))
                    print "<br>la query è: $sql<br>";
                
                if ($conn->query($sql) === TRUE)
                {
                    if(defined('DebugConnection'))
                        echo "Record updated successfully";

                    print "<h1>Grazie per aver confermato l'email'! Clicca <a href=\"somepage.php\">qui</a> per proseguire</h1>";
                }
                else
                {
                    if(defined('DebugConnectionError'))
                        echo "Error updating record: " . $conn->error;
                }    
            }
            else
            {
                //l'utente era già verificato
                print "<h1>Email già verificata. Clicca <a href=\"somepage.php\">qui</a> per proseguire</h1>";
            }
        }
        else
        {
            //il codice non corrisponde. Si tratta di un errore dell'utente o di un tentativo di attacco?
            $state = $StateDataCodeNotFound;
        }
    }
    else
    {
        //non ci sono risultati. Si tratta di un errore dell'utente o di un tentativo di attacco?
        $state = $StateDataEmailNotFound;
    }
    
    mysqli_free_result($result);
}

if(defined('Debug'))
    print "\$state=$state<br>";

if($state != $StateDataOK)
{
    //in base al valore di state si può vedere quale problema si è verificato e decidere cosa fare
    //i casi che escludono l'errore dell'utente sembrano essere:
    //$StateDataCodeNotFound e $StateDataEmailNotFound
    
    /*ESERCIZIO:
    1) CREARE UN TABELLA CHIAMATA BLACKLIST DOVE INSERIRE GLI INDIRIZZI IP DEI POTENZIALI AVVERSARI CHE TENTANO UN ATTACCO
    
    2) SALVARE L'INDIRIZZO IP IN QUESTA TABELLA OGNI VOLTA CHE FINIAMO IN QUESTO IF
    
    3) IN OGNI ALTRA PAGINA CONTROLLARE SE L'INDIRIZZO IP DEL CLIENT SI TROVA NELLA LISTA
        IN CASO POSITIVO REINDIRIZZARE VERSO LA PAGINA 404
        
        PER TROVARE L'INDIRIZZO IP DEL CLIENT: usare GetClientIP() fornita nello snippet
        PER REINDIRIZZARE: header('Location: '.$URL);
    */
}

$conn->close();
PrintBottom();
?>