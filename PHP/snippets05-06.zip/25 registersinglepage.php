<?php

require_once('functions/html.php');
require_once('functions/functions.php');

$PostRequest = IsPostRequest();

PrintTop($PostRequest ? "registrazione" : "registrati");

require_once('functions/conf.php');
require_once('../Private/connection.php');

if($PostRequest)
{
    $nome = isset($_POST['fname']) ? $_POST['fname'] : "";
    $cognome = isset($_POST['lname']) ? $_POST['lname'] : "";
    $email = isset($_POST['email']) ? $_POST['email'] : "";
    $password = isset($_POST['password']) ? $_POST['password'] : "";

    if(defined('DebugPOST'))
    {
        print "nome=$nome<br>";
        print "cognome=$cognome<br>";
        print "email=$email<br>";
        print "password=$password<br>";
    }
    
    if(isset($_POST['submit']))
    {
        $conn = connect();
        
        //sql insert create table
        $sql = "INSERT INTO MyGuests (firstname, lastname, email, secretpassword) VALUES";
        $sql .= " ('$nome', '$cognome', '$email', '$password')";

        if ($conn->query($sql) === TRUE)
        {
            ?><h1>Registrazione effettuata con successo!</h1><br><?php
            if(defined('DebugConnection'))
                echo "New record created successfully.<br>";
        }
        else 
        {
            if(defined('DebugConnectionError'))
                echo "Error: " . $sql . "<br>" . $conn->error;
        }
        
        $conn->close();
    }
    else
    {
        ?><h1>Qualcosa è andato storto, riprova</h1><br><?php
    }
}
else
{
?>
<h1>Registrati</h1><br>
<form action="<?php print $_SERVER['PHP_SELF']; ?>" method="post">
    <label for="fname">Nome:</label><br>
    <input type="text" id="fname" name="fname" value=""><br><br>
    
    <label for="lname">Cognome:</label><br>
    <input type="text" id="lname" name="lname" value=""><br><br>
    
    <label for="email">email:</label><br>
    <input type="text" id="email" name="email" value=""><br><br>
    
    <label for="pass">Password (8 characters minimum):</label><br>
    <input type="password" id="pass" name="password" minlength="8" required><br><br>
    
    <input type="submit" name="submit" value="Registrati">
</form> 
<?php
}
PrintBottom();
?>



        

