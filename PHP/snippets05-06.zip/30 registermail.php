<?php

require_once('functions/html.php');
require_once('functions/functions.php');

$PostRequest = IsPostRequest();

PrintTop($PostRequest ? "registrazione" : "registrati");

require_once('functions/conf.php');
require_once('../Private/connection.php');

if($PostRequest)
{
//    $nome = isset($_POST['fname']) ? $_POST['fname'] : "";
//    $cognome = isset($_POST['lname']) ? $_POST['lname'] : "";
//    $email = isset($_POST['email']) ? $_POST['email'] : "";
//    $password0 = isset($_POST['password0']) ? $_POST['password0'] : "";
//    $password1 = isset($_POST['password1']) ? $_POST['password1'] : "";
    
    $nome = GetValue($_POST['fname']);
    $cognome = GetValue($_POST['lname']);
    $email = GetValue($_POST['email']);
    $password0 = GetValue($_POST['password0']);
    $password1 = GetValue($_POST['password1']);


    if(defined('DebugPOST'))
    {
        print "nome=$nome<br>";
        print "cognome=$cognome<br>";
        print "email=$email<br>";
        print "password0=$password0<br>";
        print "password1=$password1<br>";
    }
    
    if(isset($_POST['submit']))
    {
        $ok = true;
        if(!IsEmail($email))
        {
            $ok = false;
            ?><h1>Inserire un'email valida</h1><br><?php
        }
        if(strlen($nome)<2)
        {
            $ok = false;
            ?><h1>Inserire un nome valido</h1><br><?php
        }
        
        if(strlen($cognome)<3)
        {
            $ok = false;
            ?><h1>Inserire un cognome valido</h1><br><?php
        }
        
        if(strlen($password0)<8)//si potrebbero fare altri controlli sulla robustezza
        {
            $ok = false;
            ?><h1>Inserire una password valida</h1><br><?php
        }
        else
        {
            if($password0!=$password1)
            {
                $ok = false;
                ?><h1>Le password non coincidono</h1><br><?php
            }   
        }
        
        if($ok)
        {
            $conn = connect();
            $randomcode = GenerateRandomString();
            $sql = "INSERT INTO MyGuests (firstname, lastname, email, secretpassword, randomcode) VALUES";
            $sql .= " ('$nome', '$cognome', '$email', '$password0', '$randomcode')";

            if(defined('DebugQeury'))
                print "<br>la query è: $sql<br>";
            
            if ($conn->query($sql) === TRUE)
            {
                ?><h1>Registrazione effettuata con successo! Conferma la tua email cliccando sul link che ti abbiamo inviato</h1><br><?php
                if(defined('DebugConnection'))
                    echo "New record created successfully.<br>";
            }
            else 
            {
                if(defined('DebugConnectionError'))
                    echo "Error: " . $sql . "<br>" . $conn->error;
            }
            $conn->close();  
            SendEmailForSubscription($email, $randomcode, defined('Debug'));
        }
        else
        {
            ?>
            <form action="<?php print $_SERVER['PHP_SELF']; ?>" method="post">
                <label for="fname">Nome:</label><br>
                <input type="text" id="fname" name="fname" value="<?php print $nome; ?>"><br><br>

                <label for="lname">Cognome:</label><br>
                <input type="text" id="lname" name="lname" value="<?php print $cognome; ?>"><br><br>

                <label for="email">email:</label><br>
                <input type="text" id="email" name="email" value="<?php print $email; ?>"><br><br>

                <label for="pass0">Password (8 characters minimum):</label><br>
                <input type="password" id="pass0" name="password0" minlength="8" required><br><br>
                
                <label for="pass1">Conferma Password:</label><br>
                <input type="password" id="pass1" name="password1" minlength="8" required><br><br>
                

                <input type="submit" name="submit" value="Registrati">
            </form> 
            <?php
        }
    }
    else
    {
        ?><h1>Qualcosa è andato storto, riprova</h1><br><?php
        //perchè il form non ha un nome?
        //da dove vengono i dati che abbiamo ricevuto?
        //se il nome del form è 'submit' abbiamo la garanzia che i dati provengono dalla nostra pagina di registrazione?
        /*
        ESERCIZIO:
        1) IN <INPUT TYPE="SUBMIT" NAME="SUBMIT" VALUE="REGISTRATI">
        INSERIRE UN NOME CASUALE GENERATO A RUNTIME
        
        2) SALVARE QUESTO NOME IN UNA TABELLA CREATA APPOSITAMENTE
        
        3) CONFRONTARE IL NOME CHE RICEVIAMO IN $_POST['SUBMIT'] PER STABILIRE SE LA RICHIESTA DI REGISTRAZIONE PROVIENE SEMPRE DALLA NOSTRA PAGINA
        */
    }
}
else
{
?>
<h1>Registrati</h1><br>
<form action="<?php print $_SERVER['PHP_SELF']; ?>" method="post">
    <label for="fname">Nome:</label><br>
    <input type="text" id="fname" name="fname" value=""><br><br>
    
    <label for="lname">Cognome:</label><br>
    <input type="text" id="lname" name="lname" value=""><br><br>
    
    <label for="email">email:</label><br>
    <input type="text" id="email" name="email" value=""><br><br>
    
    <label for="pass0">Password (8 characters minimum):</label><br>
    <input type="password" id="pass0" name="password0" minlength="8" required><br><br>
                
    <label for="pass1">Conferma Password:</label><br>
    <input type="password" id="pass1" name="password1" minlength="8" required><br><br>
    
    <input type="submit" name="submit" value="Registrati">
</form> 
<?php
}
PrintBottom();
?>