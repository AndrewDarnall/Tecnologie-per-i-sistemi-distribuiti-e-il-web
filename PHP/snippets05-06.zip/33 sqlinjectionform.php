<?php

require_once('functions/html.php');

PrintTop("SQL Injection");
require_once('functions/conf.php');
require_once('../Private/connection.php');


if($_SERVER['REQUEST_METHOD']=='GET')
{
    ?>
    <form action="<?php print $_SERVER['PHP_SELF']; ?>" method="post">
        <label for="email">email:</label><br>
        <input type="text" id="email" name="email" value=""><br><br>
        <label for="password">password:</label><br>
        <input type="password" id="password" name="pass" value=""><br><br>
        <input type="submit" name="submit" value="vai">
    </form>
    <?php
}
else
{
 $conn = connect();

 $email = $_POST['email'];
 $password = $_POST['pass'];

 $sql = "SELECT * FROM MyGuests WHERE email='$email' and secretpassword='$password'";

 if(defined('DebugQuery'))
    print ("<br><h1>la query è: <b>$sql</b></h1>");

 $result = $conn->query($sql);

 if ($result->num_rows > 0)
 {
     // output data of each row
    while($row = $result->fetch_assoc())
    {
        echo "id: " . $row["id"]. " - Nome: " . $row["firstname"]. " - Cognome: " . $row["lastname"]. " - email: <a href=\"mailto:" . $row["email"]."\">" . $row["email"] . "</a><br>\n";
    }
 }
 else
 {
     if(defined('Debug'))
        echo "0 results";
 }

 $conn->close();
 PrintBottom();  
}
?>