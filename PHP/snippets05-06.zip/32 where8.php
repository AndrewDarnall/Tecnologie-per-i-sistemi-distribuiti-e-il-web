<?php
require_once('functions/html.php');

PrintTop("where");
require_once('functions/conf.php');
require_once('../Private/connection.php');

$conn = connect();
//$conn = ConnectPDO();


$email = $_GET['email'];
$password = $_GET['pass'];



//select
$sql = "SELECT * FROM MyGuests WHERE email='$email' and secretpassword='$password'";

print ("<br><h1>la query è: <b>$sql</b></h1>");

$result = $conn->query($sql);



if ($result->num_rows > 0)
{
  // output data of each row
  while($row = $result->fetch_assoc())
  {
    echo "id: " . $row["id"]. " - Nome: " . $row["firstname"]. " - Cognome: " . $row["lastname"]. " - email: <a href=\"mailto:" . $row["email"]."\">" . $row["email"] . "</a><br>\n";
  }
}
else
{
  echo "0 results";
}


$conn->close();
PrintBottom();

?>