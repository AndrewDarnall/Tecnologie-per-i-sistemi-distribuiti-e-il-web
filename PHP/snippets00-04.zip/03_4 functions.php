<?php

function Error404()
{
    header($_SERVER["SERVER_PROTOCOL"] . "404 Not Found");//si usa $_SERVER["SERVER_PROTOCOL" anzichè scrivere HTTP/1.1 ecc visto che il protocollo potrebbe (potenzialmente) cambiare
    exit();//spedisci al browser
}

function Error500())
{
    header($_SERVER["SERVER_PROTOCOL"] . "500 Internal Server Error");
}


?>