<?php
require_once('functions/html.php');

PrintTop("where");
require_once('functions/conf.php');
require_once('../Private/connection.php');

$id = isset($_GET['id']) ? $_GET['id'] : "";
//$id = $_GET['id'] ?? "";

$id = htmlspecialchars($id);

print "<h1>l'id richiesto e' $id</h1><br><br><br><br><br><br>";

if($id=="")
{
    print "<h1>Richiesta sbagliata!</h1><br>";
}
else
{
    //select
    $sql = "SELECT * FROM MyGuests WHERE id='$id'";
    if(defined('DebugQuery'))
        print "<br>La query e': $sql<br><br>";
    
    $result = $conn->query($sql);

    if ($result->num_rows > 0)
    {
      // output data of each row
      while($row = $result->fetch_assoc())
      {
        echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. " <a href=\"mailto:" . $row["email"]."\">" . $row["email"] . "</a><br>\n";
      }
    }
    else
    {
      print "<h1>Richiesta sbagliata!!!</h1><br>";
    }
}

$conn->close();
PrintBottom();

?>