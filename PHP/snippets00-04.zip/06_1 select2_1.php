<?php
require_once('functions/html.php');
require_once('functions/conf.php');

PrintTop("Select");

require_once('../Private/connection.php');

//select
$sql = "SELECT id, firstname FROM MyGuests ORDER BY id";
$result = $conn->query($sql);

if ($result->num_rows > 0)
{
?>
    <label for="guests">Scegli un id:</label>
    <select name="table_id" id="table_id">
<?php     
    while($row = $result->fetch_assoc())
    {
        print "<option value='" . $row['id']. "'>" . $row['firstname']. "</option>\n";
    }
}
?>
    </select> 
<?php   

$conn->close();
PrintBottom();

?>
