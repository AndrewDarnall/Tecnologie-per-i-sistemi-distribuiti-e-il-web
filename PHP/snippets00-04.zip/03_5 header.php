<?php

Error404();
//Error500();
//header("Location: https://www.unict.it/");

?>