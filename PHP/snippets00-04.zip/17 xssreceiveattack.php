<?php
$seed = $_GET['c'];

print "il seed rubato è:<br>$seed";

?>
