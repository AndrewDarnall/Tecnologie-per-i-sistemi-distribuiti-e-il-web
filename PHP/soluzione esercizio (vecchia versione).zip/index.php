<html>
<head>
    <title>Videoteca</title>
</head>
<body>
<?php

require_once('json_fake_db.php');

function PrintFilmList()
{
    $array = ReadAllFilms();
    ?>
    
    <table border="1">
    <th>Titolo</th>
    <th>Anno</th>
    <th>Paese</th>
    <th>Regista</th>
    <th>Link</th>
    <th></th>
    <th>Azioni</th>
    
    <?php
    if($array)
    {
        foreach ($array as $film => $data)
        {
            $array = $data;
            print '<form action="'. $_SERVER['PHP_SELF'] . '" method="post">';
            print '<tr>';
            print ' <td><input type="hidden" id="titolo_vecchio" name="titolo_vecchio" value="' . $film . '">';
            print ' <input type="text" id="titolo" name="titolo" value="' . $film . '"></td>';
            print ' <td><input type="text" id="anno" name="anno" value="' . $array['anno'] . '"></td>';
            print ' <td><input type="text" id="paese" name="paese" value="' . $array['paese'] . '"></td>';
            print ' <td><input type="text" id="regista" name="regista" value="' . $array['regista'] . '"></td>';
            print ' <td><input type="text" id="link" name="link" value="' . $array['link'] . '"></td>';
            print ' <td>';
            if($array['link']!="")
                print '<input type="submit" name="aprilink" value="apri il link">';
            print '</td>';
            print ' <td><input type="submit" name="modifica" value="modifica">';
            print ' <input type="submit" name="elimina" value="elimina"></td>';
            print '</tr>';
            print '</form>';
        }
    }
    ?>
    
    <form action="<?php print $_SERVER['PHP_SELF'];?>" method="post">
    <tr>
    <td><input type="text" id="titolo" name="titolo" value=""></td>
    <td><input type="text" id="anno" name="anno" value=""></td>
    <td><input type="text" id="paese" name="paese" value=""></td>
    <td><input type="text" id="regista" name="regista" value=""></td>
    <td><input type="url" id="link" name="link" value=""></td>
    <td><input type="submit" name="nuovo" value="nuovo"></td>
    </tr>
    </form>
    </table>
    
    <?php
}

if($_SERVER['REQUEST_METHOD']==='POST')
{
    $action="";
    if(isset($_POST['nuovo']))
        $action="nuovo";
    
    if(isset($_POST['modifica']))
        $action="modifica";
        
    if(isset($_POST['elimina']))
        $action="elimina";
        
    if(isset($_POST['aprilink']))
        $action="link";

    switch ($action)
    {
    case "nuovo":
        $titolo=$_POST['titolo'];
        $anno=$_POST['anno'];
        $paese=$_POST['paese'];
        $regista=$_POST['regista'];
        $link=$_POST['link'];
        if($titolo!="" && $anno!="" && $paese!="" && $regista!="")    
        {
            $data = array('anno' => $anno, 'paese' => $paese, 'regista' => $regista, 'link' => $link);
            CreateFilm($titolo, $data);
        }
        else
        {
            ?>
            <script type="text/javascript">
                alert('inserire titolo, anno, paese e regista');
            </script>
            <?php
        }
        header("Refresh:0");
        break;
            
    case "modifica":
        $titolo_vecchio=$_POST['titolo_vecchio'];
        $titolo=$_POST['titolo'];
        $anno=$_POST['anno'];
        $paese=$_POST['paese'];
        $regista=$_POST['regista'];
        $link=$_POST['link'];
        if($titolo!="" && $anno!="" && $paese!="" && $regista!="")    
        {
            $data = array('anno' => $anno, 'paese' => $paese, 'regista' => $regista, 'link' => $link);
            UpdateFilm($titolo_vecchio, $titolo, $data);
        }
        else
        {
            ?>
            <script type="text/javascript">
                alert('inserire titolo, anno, paese e regista');
            </script>
            <?php
        }
        header("Refresh:0");
        break;
            
    case "elimina":
        $titolo=$_POST['titolo'];
        DeleteFilm($titolo);
        header("Refresh:0");
        break;
            
    case "link":
        $link=$_POST['link'];
        ?>
        <script type="text/javascript">
            window.open('<?php print $link; ?>', '_blank');
        </script>
        <?php
        header("Refresh:0");
        break;
    }   
}
else
    PrintFilmList();
?>
</body>
</html>